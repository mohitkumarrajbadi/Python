def linear_search (array,element):
    for i in range(len(array)):
        if array[i] == element:
            return i
    return (-1)


array = list();
size = int(input("Enter the number you want in the array : "))
for i in range(int(size)):
     n = int(input("Input the element : "))
     array.append(int(n))

element=int(input("Enter the element you want search in the array : "))

if( linear_search(array,element) == -1):
    print("The element is not in the array")
else:
    print(linear_search(array,element))
