x = lambda a ,b :  a*b
print(x(5,6))

#using lamda in function

def myfunc(n):
    return lambda a : a * n

mytripler = myfunc(3)
mydoubler = myfunc(2)
print(mytripler(11))
print(mydoubler(11))

