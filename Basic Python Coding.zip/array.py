cars = ["Audi","Bently","Chorvet"]
for x in cars:
    print(x)
print(len(cars))

cars.append("Datsun")
cars.pop(3)

print(cars)
#creating a copy of the car
x = cars.copy()
counter = cars.count("Audi")
print(x)
print(counter)
