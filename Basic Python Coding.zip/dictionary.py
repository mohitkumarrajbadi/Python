thisdict = {

        "apple": "green",
        "banana": "yellow",
        "cherry": "red"

    }

thisdict["apple"]="red"
thisdict["damson"]="purple"
del(thisdict["banana"])
print(len(thisdict))
print(thisdict)
