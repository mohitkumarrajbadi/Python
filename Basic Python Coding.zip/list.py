thislist = ["apple","banana","cherry"]
print(thislist)
print(thislist[1])
thislist[1]="ball"
print(thislist)

thislist.append("fruits")
print(thislist)

thislist.remove("fruits")
print(thislist)

print(len(thislist))
print(thislist.sort())
