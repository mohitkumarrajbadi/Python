name = input("Enter your name : ")
print(name)
