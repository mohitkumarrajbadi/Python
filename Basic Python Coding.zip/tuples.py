thistuple = ("apple","banana","cherry")
print(thistuple)
print(len(thistuple))
