def my_function():
    print("Hello from a function")

my_function()

#PASSING PARAMETERS IN THE FUNCTION
def print_name(name):
    print("Your name is : " + name)

print_name(input("Enter the name : "))    


#FUNTION RETURNING
def my_function(x):
    return 5*x

print(my_function(3))
print(my_function(5))
