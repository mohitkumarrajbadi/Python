thisset  = {"apple","banana","cherry"}

print(thisset)
thisset.add("damson")
print(thisset)

thisset.remove("damson")
print(thisset)
