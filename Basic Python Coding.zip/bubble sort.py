
def bubble_sort(array):
    for i in range(len(array)):
        for j in range(0,n-i-1):
            if array[j] > array[j+1]:
                array[j],array[j+1] = array[j+1],array[j] 
                

    
array = list()
size = int(input("Enter the size of the array : "))

for i in range(size):
    n = int(input("Enter the element : "))
    array.append(int(n))

print("The array before sorting : ",array)

bubble_sort(array)

print("The array after sorting : ",array)
