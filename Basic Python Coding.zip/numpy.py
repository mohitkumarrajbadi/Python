from numpy import * 

x = range(16)

x = reshape(x,(4,4)) 

print(x) 
