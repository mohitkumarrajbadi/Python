def sum_of_the_array(given_array):
    total = int(0)
    for i in given_array:
        total += i
    return total


given_array=[1,2,3,4,5,6,7,8,9,10]

print(sum_of_the_array(given_array))
