

def bubble_sort(array):
    for i  in range(len(array)):
        for j in range(0,len(array)-i-1):
            if array[j] > array[j+1]:
                array[j],array[j+1] = array[j+1],array[j] 




no_of_element = int(input("Enter the number of element you want in the list : "))
array = list();

for i in range(no_of_element):
     array.append(list())

for i in range (no_of_element):
    for j in range (no_of_element):
       n = input("Enter the element")
       array[i][j].append(n)

print("The array before sorting : ",array)

bubble_sort(array)

print("The array after sorting : ",array)
