s = input("enter your name")

a = print("enter a number")
a = int()

print(s)
print(a)
print(type(s))
print(type(a))
