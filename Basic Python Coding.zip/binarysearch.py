def linear_search (array,element):
    beg = int(0)
    end = int(len(array)-1)
    while beg <= end:
        mid = int((beg+end)/2)
        if array[mid] == element:
            return mid
        elif array[mid] < element:
            beg = mid + 1
        else:
            end = mid - 1


array = list();
size = int(input("Enter the number you want in the array : "))
for i in range(int(size)):
     n = int(input("Input the element : "))
     array.append(int(n))

element=int(input("Enter the element you want search in the array : "))

print(linear_search(array,element))
