fruits = ["apple","banana","cherry"]
for x in fruits:
    if x == "banana":
        continue
    print(x)

#range()

    for x in range(2,30,3):
        print(x)

